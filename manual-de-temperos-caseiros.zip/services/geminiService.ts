
import { GoogleGenAI, Type } from "@google/genai";

// Fix: Use process.env.API_KEY directly in the named parameter constructor as required
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSeasoningAdvice = async (userPrompt: string) => {
  try {
    // Fix: Use recommended model 'gemini-3-flash-preview' for basic text tasks
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userPrompt,
      config: {
        systemInstruction: `Você é um chef especialista em temperos naturais e saudáveis. 
        Seu objetivo é ajudar as pessoas a substituir temperos industrializados (caldos em cubo, saquinhos) por misturas caseiras.
        Responda sempre de forma encorajadora, em português brasileiro, e forneça receitas práticas.`,
        temperature: 0.7,
      },
    });
    // Fix: Access .text property directly (not as a function)
    return response.text;
  } catch (error) {
    console.error("Error fetching seasoning advice:", error);
    return "Desculpe, tive um problema ao buscar sua dica de tempero. Tente novamente!";
  }
};

export const generateFeaturedRecipe = async () => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Crie uma receita de um tempero caseiro versátil e saudável.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            description: { type: Type.STRING },
            ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
            instructions: { type: Type.STRING },
            bestUsedWith: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          // Fix: Use propertyOrdering as recommended in Google GenAI SDK guidelines
          propertyOrdering: ["name", "description", "ingredients", "instructions", "bestUsedWith"]
        },
      },
    });
    // Fix: Trim the response text before parsing as JSON string
    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Error generating recipe:", error);
    return null;
  }
};
