
import React from 'react';

const Hero: React.FC = () => {
  const PAYMENT_LINK = "https://ambienteseguro.org.ua/c/d55998c7c6";

  return (
    <section className="relative min-h-[95vh] md:min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image com Enquadramento Mobile Otimizado */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-[center_top] md:bg-center"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1532336414038-cf19250c5757?q=80&w=2070&auto=format&fit=crop')" }}
      >
        <div className="absolute inset-0 bg-stone-900/85 md:bg-stone-900/70 backdrop-blur-[1px]"></div>
      </div>

      <div className="relative z-10 max-w-5xl px-4 md:px-6 text-center text-white pt-16 md:pt-20">
        <span className="inline-block px-4 py-1.5 mb-6 text-[10px] md:text-xs font-bold tracking-[0.2em] uppercase bg-emerald-600 text-white rounded-full animate-glow shadow-lg border border-emerald-400/30">
          +30 receitas de temperos caseiros
        </span>
        <h1 className="text-4xl sm:text-5xl md:text-8xl font-bold mb-6 md:mb-8 leading-[1.1] tracking-tight">
          Manual de <br />
          <span className="text-emerald-500">Temperos Caseiros</span>
        </h1>
        <p className="text-base md:text-2xl mb-10 md:text-3xl text-stone-300 font-light max-w-3xl mx-auto leading-relaxed px-2">
          Elimine conservantes e realce o sabor real dos seus alimentos com técnicas profissionais.
        </p>
        
        <div className="flex flex-col items-center gap-6 md:gap-8 w-full max-w-xs md:max-w-md mx-auto">
          <a 
            href={PAYMENT_LINK}
            className="w-full inline-block px-8 py-5 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-none text-lg md:text-xl transition-all shadow-xl uppercase tracking-widest decoration-none text-center"
          >
            Quero garantir meu manual
          </a>
          <p className="text-[10px] md:text-sm text-stone-400 uppercase tracking-widest font-semibold">
            Acesso Imediato • Início Hoje
          </p>
        </div>
      </div>
    </section>
  );
};

export default Hero;
