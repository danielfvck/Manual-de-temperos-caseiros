
import React, { useState, useEffect } from 'react';

const CountdownTimer: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { hours, minutes, seconds } = prev;
        
        if (seconds > 0) {
          seconds--;
        } else {
          seconds = 59;
          if (minutes > 0) {
            minutes--;
          } else {
            minutes = 59;
            if (hours > 0) {
              hours--;
            } else {
              // Reseta para 24h para manter a urgência sempre ativa no carregamento
              hours = 23;
              minutes = 59;
              seconds = 59;
            }
          }
        }
        return { hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatNumber = (num: number) => num.toString().padStart(2, '0');

  return (
    <div className="flex flex-col items-center gap-3 mb-8">
      <span className="text-emerald-400 font-bold uppercase tracking-[0.3em] text-[10px] md:text-xs">
        ADQUIRA SÓ HOJE
      </span>
      <div className="flex gap-4 md:gap-6">
        {[
          { label: 'HORAS', value: timeLeft.hours },
          { label: 'MINUTOS', value: timeLeft.minutes },
          { label: 'SEGUNDOS', value: timeLeft.seconds },
        ].map((item, index) => (
          <React.Fragment key={item.label}>
            <div className="flex flex-col items-center">
              <div className="bg-white/10 backdrop-blur-md w-14 h-14 md:w-20 md:h-20 flex items-center justify-center rounded-lg border border-white/20 shadow-xl">
                <span className="text-2xl md:text-4xl font-black font-mono tracking-tighter">
                  {formatNumber(item.value)}
                </span>
              </div>
              <span className="text-[8px] md:text-[10px] mt-2 font-bold opacity-40 tracking-widest">
                {item.label}
              </span>
            </div>
            {index < 2 && (
              <div className="flex items-center pt-2">
                <span className="text-2xl md:text-4xl font-light opacity-30">:</span>
              </div>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default CountdownTimer;
