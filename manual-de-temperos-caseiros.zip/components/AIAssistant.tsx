
import React, { useState } from 'react';
import { getSeasoningAdvice } from '../services/geminiService';

const AIAssistant: React.FC = () => {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setLoading(true);
    const advice = await getSeasoningAdvice(input);
    setResponse(advice);
    setLoading(false);
  };

  return (
    <section className="py-32 bg-stone-900 text-white">
      <div className="max-w-4xl mx-auto px-6">
        <div className="border-l-4 border-emerald-500 pl-8 mb-12">
          <h2 className="text-4xl font-bold mb-4 uppercase tracking-tighter">Consultoria Gastronômica AI</h2>
          <p className="text-stone-400 text-lg">Teste a base de conhecimento do manual. Pergunte sobre qualquer combinação de alimentos.</p>
        </div>

        <div className="bg-stone-800/50 p-8 md:p-12 rounded-sm border border-stone-700">
          <form onSubmit={handleSubmit} className="mb-8">
            <div className="flex flex-col sm:flex-row gap-4">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ex: Melhor combinação para peixes brancos"
                className="flex-1 bg-stone-950 border border-stone-700 rounded-sm px-6 py-5 text-white placeholder-stone-600 focus:outline-none focus:border-emerald-500 transition-colors"
              />
              <button 
                type="submit"
                disabled={loading}
                className="bg-emerald-600 hover:bg-emerald-500 disabled:bg-stone-700 px-10 py-5 rounded-sm font-bold transition-all uppercase tracking-widest text-sm"
              >
                {loading ? 'Processando...' : 'Consultar'}
              </button>
            </div>
          </form>

          {response && (
            <div className="bg-stone-950/50 p-8 border-l-2 border-emerald-800 animate-in fade-in duration-700">
              <p className="whitespace-pre-wrap leading-relaxed text-stone-300 font-medium italic">
                {response}
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default AIAssistant;
