
import React from 'react';

const FeatureCard: React.FC<{ title: string; desc: string; image: string }> = ({ title, desc, image }) => (
  <div className="bg-white border border-stone-200 overflow-hidden hover:border-emerald-300 transition-colors flex flex-col h-full">
    <div className="aspect-video sm:aspect-auto sm:h-64 overflow-hidden">
      <img 
        src={image} 
        alt={title} 
        className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700" 
      />
    </div>
    <div className="p-6 md:p-10 flex flex-col flex-1">
      <h3 className="text-lg md:text-2xl font-bold mb-3 md:mb-4 uppercase tracking-tight text-stone-900">{title}</h3>
      <div className="w-8 md:w-12 h-1 bg-emerald-600 mb-4 md:mb-6"></div>
      <p className="text-stone-600 leading-relaxed font-medium text-xs md:text-base flex-1">{desc}</p>
    </div>
  </div>
);

const Features: React.FC = () => {
  return (
    <section className="py-16 md:py-32 bg-stone-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-10 md:mb-20 text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 md:mb-6 text-stone-900 tracking-tight">Conteúdo Programático</h2>
          <p className="text-stone-500 text-base md:text-xl max-w-2xl mx-auto">O que você receberá ao garantir sua cópia hoje.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <FeatureCard 
            title="Blends Desidratados"
            desc="Fórmulas exatas para criação de mix de ervas e especiarias em pó. Substitua caldos industriais por blends de longa duração."
            image="https://images.unsplash.com/photo-1596040033229-a9821ebd058d?q=80&w=2070&auto=format&fit=crop"
          />
          <FeatureCard 
            title="Pastas de Conservação"
            desc="Técnicas de armazenamento de ervas frescas em meios lipídicos e salinos para uso imediato em refogados."
            image="https://images.unsplash.com/photo-1476718406336-bb5a9690ee2a?q=80&w=1974&auto=format&fit=crop"
          />
          <FeatureCard 
            title="Sais Funcionais"
            desc="Desenvolvimento de sais aromáticos com propriedades funcionais, focados na redução drástica de sódio no dia a dia."
            image="https://images.unsplash.com/photo-1504113888839-1c8eb50233d3?q=80&w=2029&auto=format&fit=crop"
          />
        </div>
      </div>
    </section>
  );
};

export default Features;
